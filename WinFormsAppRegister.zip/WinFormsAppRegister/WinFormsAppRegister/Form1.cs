﻿namespace WinFormsAppRegister
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {

            string firstname = FirstNameTextBox.Text;
            string lastname = LastNametextBox.Text;
            string cellphone = CellphoneTextBox.Text;
            string nationalcode = NationalcodetextBox.Text;
            //bool gender = FemaleradioButton.Checked;

            if (string.IsNullOrEmpty(firstname) || string.IsNullOrEmpty(lastname) || string.IsNullOrEmpty(cellphone) || string.IsNullOrEmpty(nationalcode) || (!FemaleradioButton.Checked && !MaleradioButton.Checked))
            {
                MessageBox.Show("please enter your information ! ");
                return;
            }

            cellphone = cellphone.Replace('۰', '0').Replace('۱', '1').Replace('۲', '2').Replace('۳', '3').Replace('۴', '4').Replace('۵', '5')
                                 .Replace('۶', '6').Replace('۷', '7').Replace('۸', '8').Replace('۹', '9');

            if (cellphone.Length < 11 || cellphone.Length > 13 || (!cellphone.StartsWith("09") && !cellphone.StartsWith("989") && !cellphone.StartsWith("+989")))
            {
                MessageBox.Show("please enter your cell number correctly ! ");
                return;
            }
            else
            {
                if (cellphone.StartsWith("989"))
                {
                    cellphone = "0" + cellphone.Substring(2, 10);
                }
                else if (cellphone.StartsWith("+989"))
                {
                    cellphone = "0" + cellphone.Substring(3, 10);
                }
            }

            long nationalCode = 0;
            if (nationalcode.Length != 10 || !long.TryParse(nationalcode, out nationalCode))
            {
                MessageBox.Show("please enter your national Code correctly ! ");
                return;
            }
            
            var gendar = FemaleradioButton.Checked ? "زن" : "مرد";
            OutPutTextBox.Text = $"نام: {firstname}، نام خانوادگی: {lastname}، شماره تلفن همراه: {cellphone} ، کدملی: {nationalcode} ، جنسیت: {gendar}";
        }
    }
}
